#! /bin/bash
#Scripts de backup - punto 1 del manual

#echo "Backup script inicial listo."

#Fecha de formato ANSI
FECHA=$(date +%Y%m%d)

#captura de argumentos
ORIGEN="$1"
DESTINO="$2"

#mostrar ayuda -help, punto 5
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 1
fi

#validar argumentos
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debe indicar el directorio de origen."
    exit 1
fi
#validar  existencia, punto 6
if [ ! -d "$ORIGEN" ]; then
   echo "Error: El directorio de origen '$ORIGEN' no existe."
   exit 1
fi

#validar que /backup_dir este montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: /backup_dir no esta montado."
    exit 1
fi

#Nombre del archivo
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

#Realizar backup comprimido
tar -czpf "$ARCHIVO" "$ORIGEN"
echo "Backup generado: $ARCHIVO"


